# CannaZen 🌿

> Boutique CBD Premium — Clone Sixty8 style dark luxury

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/AedenMath/CannaZen)

## 🚀 Stack

- **HTML / CSS / JS** — Site statique 100%, aucune dépendance
- **Vercel** — Déploiement automatique à chaque push GitHub
- **Images** — Vraies photos Cocorikush via CDN

## 📦 Contenu

- Design identique Sixty8 (dark luxury, Barlow Condensed, or `#c9aa71`)
- 24 produits avec vraies images & prix exacts (Magic Sauce, HEC-10, THCA, CBN, CBD, Vapes)
- Panier persistant localStorage
- Modal produit avec sélecteur variants
- Flash Sales + timer countdown
- Codes promo : `CZ20`, `CANNAZEN10`, `KUSH15`, `MAGIC30`
- Age gate +18
- Weed Box mensuelle
- Responsive mobile

## 🛠 Déploiement

### Via Vercel (recommandé)

1. Fork ou clone ce repo sur GitHub
2. Va sur [vercel.com](https://vercel.com) → **Add New Project**
3. Importe le repo GitHub
4. Clique **Deploy** — c'est tout ✅

### En local

```bash
# Ouvre simplement le fichier dans ton navigateur
open index.html
```

## 🗂 Structure

```
cannazen/
├── index.html      # Site complet (HTML + CSS + JS)
├── vercel.json     # Config déploiement Vercel
└── README.md       # Ce fichier
```

## 🔑 Codes promo actifs

| Code | Remise |
|------|--------|
| `CZ20` | -20% |
| `CANNAZEN10` | -10% |
| `KUSH15` | -15% |
| `MAGIC30` | -30% |

## ⚠️ Légal

Produits légaux en France. THC < 0,3%. +18 ans uniquement.
